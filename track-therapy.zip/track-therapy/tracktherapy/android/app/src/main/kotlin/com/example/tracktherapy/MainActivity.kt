package com.example.tracktherapy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
